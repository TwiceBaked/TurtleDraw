# TurtleDrawV01.gc
# Gabe Carlson
# gabrieljcarlson@lewisu.edu
# The file "TurlteDrawLines.txt" is required for program to run.